package edu.iastate.cs228.proj2;


public class FileConfigurationException extends Exception {
	//TODO: implement appropriate message, etc. 
	/**
	 * @author Mason Walls
	 */
	public FileConfigurationException(){

        super("Check file configuration");

    }
	
}